FIGS2 data package
==================

This archive contains the data required by FIGS2.ipynb to regenerate Supplementary Figure 2.

Files:
- figs2_rmse_values.csv: trajectory-wise torque RMSE values for each training-set size and joint, extracted from results_model_*.pt.
- figs2_pairwise_statistics.csv: two-sided Mann-Whitney U tests with Benjamini-Hochberg FDR correction.
- figs2_fdr_q_matrix_J1.csv and figs2_fdr_q_matrix_J2.csv: symmetric FDR-adjusted q-value matrices used for the two panels.
- figs2_metadata.json: source hashes, dataset sizes, significance threshold, and provenance metadata.

No synthetic, randomized replacement, or placeholder data were generated.
