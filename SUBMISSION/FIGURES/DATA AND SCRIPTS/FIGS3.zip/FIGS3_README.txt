FIGS3 data package
==================

This archive contains the data required by FIGS3.ipynb to regenerate Supplementary Figure 3.

Files:
- figs3_rmse_values.csv: trajectory-wise RMSE of angle, velocity and acceleration for the closed-loop forward simulation with the learned Appell energy (learned_S, Section 6 / Fig. 6) and with the analytical Gibbs-Appell function in the same solver (analytical_S, Section 7), per joint, on the identical 50 trajectories and RK4 reference.
- figs3_statistics.csv: per quantity and joint, Shapiro-Wilk normality tests, primary comparison (one-way ANOVA if both groups are normal, otherwise Kruskal-Wallis H-test) with Benjamini-Hochberg FDR correction across the six comparisons, secondary two-sided Mann-Whitney U (U statistic for analytical versus learned) and paired Wilcoxon signed-rank tests, descriptive statistics and effect sizes (median ratio and Cliff's delta, analytical versus learned).
- figs3_metadata.json: source hashes, solver configuration, objectives, reference description, statistical settings, figure conventions, and provenance metadata.

The figure shows RMSE on logarithmic axes, one panel per joint (rows) and per quantity (columns). Each line joins the error with the learned energy (filled marker) and the error with the analytical function (open marker) of one trajectory; heavy bars mark the medians. An asterisk above a pair marks a Benjamini-Hochberg-adjusted q value of the primary test below 0.05 (ns otherwise).
