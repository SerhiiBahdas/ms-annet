FIG3 data package
=================

This archive contains the data required by FIG3.ipynb to regenerate manuscript Figure 3.

Files:
- fig3_test_rmse_history.csv: periodic test RMSE values during training, extracted from history_*.pt.
- fig3_train_loss_history.csv: per-epoch training loss history, extracted from history_*.pt for provenance.
- fig3_training_times.csv: wall-clock training times from time_*.txt.
- fig3_rmse_values.csv: trajectory-wise torque RMSE values for joints 1 and 2, extracted from results_model_*.pt.
- fig3_best_checkpoints.csv: minimum-test-RMSE checkpoint for each dataset size.
- fig3_power_law_fits.csv: power-law fit parameters computed from the median RMSE values.
- fig3_pairwise_statistics.csv: two-sided Mann-Whitney U tests with Benjamini-Hochberg FDR correction.
- fig3_metadata.json: source hashes and archive metadata.
