FIG6 data package
=================

This archive contains the data required by FIG6.ipynb to regenerate manuscript Figure 6.

Files:
- fig6_arrays.npz: full numerical and neural rollout arrays, RMSE arrays, trajectory timings, and latency values.
- fig6_rmse_values.csv: trajectory-wise RMSE values in long tabular form.
- fig6_trajectory_timing.csv: per-trajectory numerical ODE and neural-solver wall-clock times.
- fig6_latency_values.csv: per-query forward-solver and inverse-model latency measurements.
- fig6_latency_summary.csv: summary statistics for the latency distributions.
- fig6_demo_trajectory.csv: tabular data for the representative trajectory plotted in panel a.
- fig6_metadata.json: source hashes, solver configuration, and provenance metadata.
