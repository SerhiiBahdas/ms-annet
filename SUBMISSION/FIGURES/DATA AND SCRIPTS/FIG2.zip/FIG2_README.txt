FIG2 data package
=================

This archive contains the data required by FIG2.ipynb to regenerate Figure 2.

Files:
- fig2_hyperparameter_trials.csv: cleaned plotting table derived from optuna_search_results.csv.
- fig2_raw_optuna_search_results.csv: Optuna trial table of optuna_search_results.csv, saved again (values agree to 15 significant digits).
- fig2_best_configuration.json: best-performing configuration used for red-diamond markers.
- fig2_hyperparameter_sensitivity.csv: sensitivity values used for panel h.
- optuna_study.pkl: saved Optuna study object retained for provenance.
- fig2_metadata.json: source hashes and package metadata.
