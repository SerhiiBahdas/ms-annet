FIGS1 data package
==================

This archive contains the data required by FIGS1.ipynb to regenerate Supplementary Figure 1.

Files:
- figs1_optuna_trials_raw.csv: original Optuna trial table copied from optuna_search_results.csv.
- figs1_parallel_coordinates_trials.csv: plotting table with activation codes, best/top-decile flags, and unused deeper layer widths encoded as 0.
- figs1_axis_definitions.json: axis scaling, labels, and tick definitions used by the parallel-coordinate plot.
- figs1_best_trial.json: best-performing Optuna trial used for the red polyline.
- figs1_metadata.json: source hashes and provenance metadata.

No synthetic, randomized replacement, or placeholder data were generated.
