FIG4 data package
=================

This archive contains the data required by FIG4.ipynb to regenerate manuscript Figure 4.

Files:
- fig4_optimizer_grid_search.csv: one row per evaluated solver configuration (336 rows). Values were extracted from optimizer_grid_search_angle_mae_50traj_10000updates.pt and include the plotted angular error and execution-time metrics.
- fig4_pareto_front.csv: Pareto-front operating points recomputed from fig4_optimizer_grid_search.csv using mean_update_ms and mean_abs_angle_error_rad.
- fig4_highlighted_operating_points.csv: the four selected configurations marked in the figure.
- fig4_metadata.json: source hashes, grid definition, and provenance metadata.

No synthetic, randomized replacement, or placeholder data were generated.
