FIG4 data package
=================

This archive contains the data required by FIG4.ipynb to regenerate manuscript Figure 4.

Files:
- fig4_rmse_values.csv: trajectory-wise torque RMSE values for ANNet and for the direct torque-regression MLP with the same architecture (both trained on 16,000 samples), per joint, on the identical 50-trajectory fixed test set.
- fig4_statistics.csv: per-joint Shapiro-Wilk normality tests, primary group comparison (one-way ANOVA if both groups are normal, otherwise Kruskal-Wallis H-test) with Benjamini-Hochberg FDR correction, secondary two-sided Mann-Whitney U (U statistic for MLP versus ANNet) and paired Wilcoxon signed-rank tests, descriptive statistics and effect sizes (median ratio and Cliff's delta, MLP versus ANNet).
- fig4_metadata.json: source hashes, model and training configuration, run environment, test-set description, statistical settings, figure conventions, and provenance metadata.

The figure shows torque RMSE on a shared logarithmic axis, one panel per joint. Each line joins the ANNet error (filled marker) and the MLP error (open marker) of one test trajectory and is drawn in the joint colour where the MLP error is higher and in grey where it is lower; heavy bars mark the medians. An asterisk above a pair marks a Benjamini-Hochberg-adjusted q value of the primary test below 0.05 (ns otherwise).
