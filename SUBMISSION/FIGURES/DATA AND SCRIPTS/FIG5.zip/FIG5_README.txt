FIG5 data package
=================

This archive contains the data required by FIG5.ipynb to regenerate manuscript Figure 5.

Files:
- fig5_arrays.npz: full numerical and neural rollout arrays, RMSE arrays, trajectory timings, and latency values.
- fig5_rmse_values.csv: trajectory-wise RMSE values in long tabular form.
- fig5_trajectory_timing.csv: per-trajectory numerical ODE and neural-solver wall-clock times.
- fig5_latency_values.csv: per-query forward-solver and inverse-model latency measurements.
- fig5_latency_summary.csv: summary statistics for the latency distributions.
- fig5_demo_trajectory.csv: tabular data for the representative trajectory plotted in panel a.
- fig5_metadata.json: source hashes, solver configuration, and provenance metadata.

No synthetic, randomized replacement, or placeholder data were generated.
